

#include <LiquidCrystal.h>
#include <OneWire.h>
#include <DallasTemperature.h>

// ---------- LCD (DFRobot shield standart pinleri) ----------
LiquidCrystal lcd(8, 9, 4, 5, 6, 7);
// DFRobot shield D8-D9 röle pinlerini kullanıyorsa LCD pinlerini
// kütüphane tanımlamasından değiştirin. Röle için D10-D11 öneririz.

// ---------- Röle pinleri ----------
// DFRobot shield D8/D9 yerine D10/D11 kullanmak daha güvenlidir.
const int PIN_LAMBA = 11;   // Lamba röle
const int PIN_FAN   = 3;   // Fan röle
// Aktif LOW röle modülü (IN=LOW → röle çeker)
#define ROLE_AC  HIGH
#define ROLE_KAPAT LOW

// ---------- DS18B20 ----------
const int PIN_DS18B20 = 2;
OneWire oneWire(PIN_DS18B20);
DallasTemperature sensors(&oneWire);

// ---------- Analog pinler ----------
const int PIN_AKIM    = A1;   // ACS712 OUT
const int PIN_AKU_V   = A2;   // Akü voltaj bölücüsü
const int PIN_PANEL_V = A3;   // Panel voltaj bölücüsü


const int ROLE1   = 18;   // 220V SECIM ROLESI
const int ROLE2 = 19;   // 220V SECIM ROLESI

// A0 DFRobot tuşlar için ayrıldı (dokunmayın)

// ---------- Voltaj bölücü sabitleri ----------
// Vout = Vin * R2 / (R1 + R2)  →  Vin = Vout * (R1+R2) / R2
// R1=30kΩ, R2=10kΩ → çarpan = 4.0
const float BOLDUCU_CARPAN = 5.8;
const float VREF = 5.0;       // Arduino referans voltajı

// ---------- ACS712 ----------
// ACS712-5A : 185 mV/A,  0-offset = VCC/2 = 2.5V
// ACS712-20A: 100 mV/A
// ACS712-30A:  66 mV/A
const float ACS_HASSASIYET  = 0.185; // V/A (5A model)
const float ACS_OFFSET_V    = 2.5;   // Sıfır akım çıkış voltajı

// ---------- Durum değişkenleri ----------
bool lambaAcik    = false;
int  termostatAyar = 30;     // °C
const int TERMO_MIN = 5;
const int TERMO_MAX = 80;

// ---------- Ekran sayfaları ----------
// 0: Akım + Sıcaklık   1: Akü V + Panel V   2: Termostat ayarı
int sayfa = 0;
const int SAYFA_SAYISI = 3;

// ---------- Zamanlama ----------
unsigned long sonOkumaZamani    = 0;
unsigned long sonTusZamani      = 0;
const unsigned long OKUMA_ARALIK = 1000; // ms
const unsigned long TUS_BEKLEME  = 200;  // ms debounce

// ---------- Ölçüm sonuçları ----------
float sicaklik = 0;
float akim     = 0;
float akuVolt  = 0;
float panelVolt= 0;

// ============================================================
void setup() {
  Serial.begin(9600);

  lcd.begin(16, 2);
  lcd.print(F("Solar Monitor"));
  lcd.setCursor(0, 1);
  lcd.print(F("Baslatiliyor..."));

  pinMode(PIN_LAMBA, OUTPUT);
  pinMode(PIN_FAN,   OUTPUT);

  pinMode(ROLE1, OUTPUT);
  digitalWrite(ROLE1, HIGH);
  pinMode(ROLE2, OUTPUT);
  digitalWrite(ROLE2, HIGH);  
  digitalWrite(PIN_LAMBA, ROLE_KAPAT);
  digitalWrite(PIN_FAN,   ROLE_KAPAT);

  sensors.begin();

  delay(1500);
  lcd.clear();
}

// ============================================================
void loop() {
  unsigned long simdi = millis();

  // Tuş okuma (her döngüde)
  tuslariOku();

  // Sensör okumaları (1 saniyede bir)
  if (simdi - sonOkumaZamani >= OKUMA_ARALIK) {
    sonOkumaZamani = simdi;
    sensoriOku();
    ekraniGuncelle();
    fanKontrol();
  }
}

// ============================================================
// DFRobot LCD Shield tuş okuma (A0 üzerinden ADC)
// ============================================================
int dfrobotTusOku() {
  int deger = analogRead(A0);
  if (deger < 50)   return 1; // RIGHT
  if (deger < 195)  return 2; // UP
  if (deger < 380)  return 3; // DOWN
  if (deger < 555)  return 4; // LEFT
  if (deger < 790)  return 5; // SELECT
  return 0;                   // Basılı tuş yok
}

void tuslariOku() {
  unsigned long simdi = millis();
  if (simdi - sonTusZamani < TUS_BEKLEME) return;

  int tus = dfrobotTusOku();
  if (tus == 0) return;

  sonTusZamani = simdi;

  switch (tus) {
    case 1: // RIGHT → Lamba aç/kapat
      lambaAcik = !lambaAcik;
      digitalWrite(PIN_LAMBA, lambaAcik ? ROLE_AC : ROLE_KAPAT);
      lcd.clear();
      lcd.print(F("Lamba: "));
      lcd.print(lambaAcik ? F("ACIK ") : F("KAPALI"));
      delay(600);
      lcd.clear();
      break;

    case 2: // UP → Termostat artır
      if (termostatAyar < TERMO_MAX) termostatAyar++;
      sayfa = 2; // Termostat sayfasını göster
      ekraniGuncelle();
      break;

    case 3: // DOWN → Termostat azalt
      if (termostatAyar > TERMO_MIN) termostatAyar--;
      sayfa = 2;
      ekraniGuncelle();
      break;

    case 4: // LEFT → Sayfa geri
      sayfa = (sayfa - 1 + SAYFA_SAYISI) % SAYFA_SAYISI;
      lcd.clear();
      ekraniGuncelle();
      break;

    case 5: // SELECT → Sayfa ileri
      sayfa = (sayfa + 1) % SAYFA_SAYISI;
      lcd.clear();
      ekraniGuncelle();
      break;
  }
}

// ============================================================
// Sensör okumaları
// ============================================================
void sensoriOku() {
  // Sıcaklık
  sensors.requestTemperatures();
  float t = sensors.getTempCByIndex(0);
  if (t != DEVICE_DISCONNECTED_C) sicaklik = t;

  // Akım (ACS712) - 10 örnekle ortalama al
  long toplamADC = 0;
  for (int i = 0; i < 10; i++) {
    toplamADC += analogRead(PIN_AKIM);
    delay(1);
  }
  float ortalamaADC = toplamADC / 10.0;
  float akimVolt    = ortalamaADC * (VREF / 1023.0);
  akim = (akimVolt - ACS_OFFSET_V) / ACS_HASSASIYET;

  // Akü voltajı
  float akuADC = analogRead(PIN_AKU_V) * (VREF / 1023.0);
  akuVolt = akuADC * BOLDUCU_CARPAN;

  // Panel voltajı
  float panelADC = analogRead(PIN_PANEL_V) * (VREF / 1023.0);
  panelVolt = panelADC * BOLDUCU_CARPAN;
if ( panelVolt < 12.00 )
{
  digitalWrite(ROLE1, LOW);
  digitalWrite(ROLE2, LOW);
}


  if ( panelVolt > 13.00 )
{
  digitalWrite(ROLE1, HIGH);
  digitalWrite(ROLE2, HIGH);
  
}
  // Seri port çıkışı
  Serial.print(F("T:")); Serial.print(sicaklik, 1);
  Serial.print(F("C  I:")); Serial.print(akim, 2);
  Serial.print(F("A  Aku:")); Serial.print(akuVolt, 2);
  Serial.print(F("V  Panel:")); Serial.print(panelVolt, 2);
  Serial.println(F("V"));
}

// ============================================================
// Fan termostat kontrolü
// ============================================================
void fanKontrol() {
  if (sicaklik >= termostatAyar) {
    digitalWrite(PIN_FAN, ROLE_AC);
  } else if (sicaklik < termostatAyar - 2) { // 2°C histerezis
    digitalWrite(PIN_FAN, ROLE_KAPAT);
  }
}

// ============================================================
// LCD ekran güncelleme
// ============================================================
void ekraniGuncelle() {
  switch (sayfa) {

    case 0: // Akım & Sıcaklık
        lcd.setCursor(0, 0);
if ( panelVolt < 12.00 )
{

      lcd.print(F("     SEBEKE     "));
}
if ( panelVolt > 13.00 )
{

      lcd.print(F("  SOLAR PANEL   "));
}



      lcd.setCursor(0, 1);
      lcd.print(F("Sicak: "));
      lcd.print(sicaklik, 1);
      lcd.print((char)223); // ° sembolü
      lcd.print(F("C  "));
      break;

    case 1: // Voltajlar
      lcd.setCursor(0, 0);
      lcd.print(F("Aku:   "));
      lcd.print(akuVolt, 2);
      lcd.print(F("V  "));
      lcd.print(F("Akim: "));
      lcd.print(abs(akim), 2);
      lcd.print(F("A  "));

      lcd.setCursor(0, 1);
      lcd.print(F("Panel: "));
      lcd.print(panelVolt, 2);
      lcd.print(F("V  "));
      break;

    case 2: // Termostat ayarı
      lcd.setCursor(0, 0);
      lcd.print(F("Termostat: "));
      lcd.print(termostatAyar);
      lcd.print((char)223);
      lcd.print(F("C  "));

      lcd.setCursor(0, 1);
      lcd.print(F("Sicaklik: "));
      lcd.print(sicaklik, 1);
      lcd.print((char)223);
      lcd.print(F("C  "));
      break;
  }

  // Durum göstergesi (sağ alt köşe)
  lcd.setCursor(15, 0);
  lcd.print(lambaAcik ? F("L") : F(" "));
  lcd.setCursor(15, 1);
  // Fan durumu - digital okuyarak kontrol et
  lcd.print(digitalRead(PIN_FAN) == ROLE_AC ? F("F") : F(" "));
}
