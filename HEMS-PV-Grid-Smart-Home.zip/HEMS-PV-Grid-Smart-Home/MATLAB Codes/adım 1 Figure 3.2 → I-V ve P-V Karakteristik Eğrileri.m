clear all; close all; clc;

Isc = 5.0;
Voc = 21.6;
Rs  = 0.4;
Rsh = 400;
n   = 48;
q   = 1.602e-19;
k   = 1.381e-23;
T   = 298.15;
Vt  = n * k * T / q;
I0  = (Isc - Voc/Rsh) / (exp(Voc/Vt) - 1);

S_list  = [1000, 800, 600, 400];
renkler = {'b', 'r', 'g', 'm'};
V       = linspace(0, Voc, 1000);

figure('Position', [100 100 1200 500]);

subplot(1,2,1); hold on; grid on;

for i = 1:4
    S   = S_list(i);
    Iph = Isc * (S / 1000);
    I   = zeros(1, 1000);
    for j = 1:1000
        x = Iph * 0.9;
        for it = 1:500
            ex = exp((V(j) + x*Rs) / Vt);
            f  = Iph - I0*(ex-1) - (V(j)+x*Rs)/Rsh - x;
            df = -I0*(Rs/Vt)*ex - Rs/Rsh - 1;
            dx = f/df;
            x  = x - dx;
            if abs(dx) < 1e-12
                break
            end
        end
        if x < 0
            x = 0;
        end
        I(j) = x;
    end
    plot(V, I, renkler{i}, 'LineWidth', 2.5, ...
        'DisplayName', sprintf('S = %d W/m2', S_list(i)));
end

xline(12.0, 'k--', 'LineWidth', 1.5, 'Label', 'Sebeke < 12V');
xline(13.0, 'k-',  'LineWidth', 1.5, 'Label', 'Solar > 13V');

xlabel('Gerilim (V)', 'FontSize', 12);
ylabel('Akim (A)', 'FontSize', 12);
title('I-V KarakteristikEgrisi', 'FontSize', 13, 'FontWeight', 'bold');
legend('Location', 'southwest', 'FontSize', 10);
xlim([0 Voc+1]); ylim([0 Isc+1]);

subplot(1,2,2); hold on; grid on;

for i = 1:4
    S   = S_list(i);
    Iph = Isc * (S / 1000);
    I   = zeros(1, 1000);
    for j = 1:1000
        x = Iph * 0.9;
        for it = 1:500
            ex = exp((V(j) + x*Rs) / Vt);
            f  = Iph - I0*(ex-1) - (V(j)+x*Rs)/Rsh - x;
            df = -I0*(Rs/Vt)*ex - Rs/Rsh - 1;
            dx = f/df;
            x  = x - dx;
            if abs(dx) < 1e-12
                break
            end
        end
        if x < 0
            x = 0;
        end
        I(j) = x;
    end
    P = V .* I;
    [Pmax, idx] = max(P);
    plot(V, P, renkler{i}, 'LineWidth', 2.5, ...
        'DisplayName', sprintf('S=%d  Pmax=%.0fW', S_list(i), Pmax));
    plot(V(idx), Pmax, 'o', 'MarkerSize', 9, ...
        'MarkerFaceColor', renkler{i}, 'Color', renkler{i}, ...
        'HandleVisibility', 'off');
end

xline(12.0, 'k--', 'LineWidth', 1.5, 'Label', 'Sebeke < 12V');
xline(13.0, 'k-',  'LineWidth', 1.5, 'Label', 'Solar > 13V');

xlabel('Gerilim (V)', 'FontSize', 12);
ylabel('Guc (W)', 'FontSize', 12);
title('P-V Karakteristik Egrisi', 'FontSize', 13, 'FontWeight', 'bold');
legend('Location', 'northwest', 'FontSize', 10);
xlim([0 Voc+1]);

sgtitle('PV Panel - Single Diode Model (Arduino Degerleriyle)', ...
    'FontSize', 14, 'FontWeight', 'bold');
saveas(gcf, 'Adim1_PV_Karakteristik.png');
disp('Adim 1 tamam!');