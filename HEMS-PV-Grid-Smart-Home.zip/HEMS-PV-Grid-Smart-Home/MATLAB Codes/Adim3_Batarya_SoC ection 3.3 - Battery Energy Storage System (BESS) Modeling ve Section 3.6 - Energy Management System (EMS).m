dt    = 0.01;
t_end = 24;
t     = 0:dt:t_end;
N     = length(t);

V_bat_max = 14.4;
V_bat_min = 11.0;
V_bat_nom = 12.0;
Kapasite  = 20.0;
SoC_max   = 0.95;
SoC_min   = 0.20;
eta       = 0.95;

SoC    = zeros(1,N);
SoC(1) = 0.60;

S = zeros(1,N);
for i = 1:N
    saat = t(i);
    if saat < 6
        S(i) = 0;
    elseif saat < 12
        S(i) = (saat-6)/6 * 1000;
    elseif saat < 14
        S(i) = 1000;
    elseif saat < 20
        S(i) = (20-saat)/6 * 1000;
    else
        S(i) = 0;
    end
end

P_yuk = zeros(1,N);
for i = 1:N
    saat = t(i);
    if saat < 6
        P_yuk(i) = 50;
    elseif saat < 9
        P_yuk(i) = 150;
    elseif saat < 17
        P_yuk(i) = 100;
    elseif saat < 22
        P_yuk(i) = 200;
    else
        P_yuk(i) = 80;
    end
end

Isc = 5.0;
Voc = 21.6;
Rs  = 0.4;
Rsh = 400;
n   = 48;
q   = 1.602e-19;
k   = 1.381e-23;
T   = 298.15;
Vt  = n * k * T / q;
I0  = (Isc - Voc/Rsh) / (exp(Voc/Vt) - 1);
Vmp = 17.2;

P_pv     = zeros(1,N);
P_bat    = zeros(1,N);
P_sebeke = zeros(1,N);

for i = 1:N
    Iph = Isc * (S(i)/1000);
    x   = Iph * 0.9;
    for it = 1:500
        ex = exp((Vmp + x*Rs) / Vt);
        f  = Iph - I0*(ex-1) - (Vmp+x*Rs)/Rsh - x;
        df = -I0*(Rs/Vt)*ex - Rs/Rsh - 1;
        dx = f/df;
        x  = x - dx;
        if abs(dx) < 1e-12
            break
        end
    end
    if x < 0
        x = 0;
    end
    P_pv(i) = Vmp * x;
    P_fazla = P_pv(i) - P_yuk(i);
    if P_fazla > 0
        if SoC(i) < SoC_max
            P_bat(i) = P_fazla * eta;
            P_sebeke(i) = 0;
        else
            P_bat(i) = 0;
            P_sebeke(i) = -P_fazla;
        end
    else
        if SoC(i) > SoC_min
            P_bat(i) = P_fazla / eta;
            P_sebeke(i) = 0;
        else
            P_bat(i) = 0;
            P_sebeke(i) = -P_fazla;
        end
    end
    if i < N
        dSoC = -P_bat(i) * dt / (Kapasite * V_bat_nom * 3600);
        SoC(i+1) = SoC(i) + dSoC;
        if SoC(i+1) > SoC_max
            SoC(i+1) = SoC_max;
        end
        if SoC(i+1) < SoC_min
            SoC(i+1) = SoC_min;
        end
    end
end

V_bat = V_bat_min + SoC * (V_bat_max - V_bat_min);

figure('Position', [100 100 1000 900]);

subplot(5,1,1);
plot(t, S, 'b', 'LineWidth', 2);
ylabel('W/m2');
title('Gunes Isinmi (24 Saat)');
grid on;

subplot(5,1,2);
plot(t, P_pv, 'g', 'LineWidth', 2);
hold on;
plot(t, P_yuk, 'r', 'LineWidth', 2);
ylabel('Guc (W)');
title('PV Uretim vs Ev Tuketimi');
legend('PV Uretim','Ev Tuketimi','Location','northwest');
grid on;

subplot(5,1,3);
plot(t, SoC*100, 'b', 'LineWidth', 2);
hold on;
yline(95, 'r--', 'LineWidth', 1.5, 'Label', 'Max %95');
yline(20, 'r--', 'LineWidth', 1.5, 'Label', 'Min %20');
ylabel('SoC (%)');
title('Batarya Sarj Durumu (SoC)');
grid on;
ylim([0 105]);

subplot(5,1,4);
plot(t, V_bat, 'm', 'LineWidth', 2);
hold on;
yline(12.0, 'k--', 'LineWidth', 1.5, 'Label', 'Sebeke Esigi 12V');
yline(13.0, 'k-', 'LineWidth', 1.5, 'Label', 'Solar Esigi 13V');
ylabel('Voltaj (V)');
title('Aku Voltaji (Arduino A2 Pini)');
grid on;
ylim([10 16]);

subplot(5,1,5);
plot(t, P_sebeke, 'k', 'LineWidth', 2);
ylabel('Guc (W)');
xlabel('Zaman (Saat)');
title('Sebeke Etkilesimi');
grid on;

sgtitle('Adim 3: Batarya + SoC Modeli', 'FontSize', 13);
saveas(gcf, 'Adim3_Batarya_SoC.png');
disp('Adim 3 tamam!');
