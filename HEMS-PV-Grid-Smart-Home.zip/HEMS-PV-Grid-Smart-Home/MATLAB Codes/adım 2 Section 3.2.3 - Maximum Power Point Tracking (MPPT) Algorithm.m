dt    = 0.01;
t_end = 10;
t     = 0:dt:t_end;
N     = length(t);

Isc = 5.0;
Voc = 21.6;
Rs  = 0.4;
Rsh = 400;
n   = 48;
q   = 1.602e-19;
k   = 1.381e-23;
T   = 298.15;
Vt  = n * k * T / q;
I0  = (Isc - Voc/Rsh) / (exp(Voc/Vt) - 1);

V_solar_esik  = 13.0;
V_sebeke_esik = 12.0;

S = zeros(1,N);
for i = 1:N
    if t(i) < 4
        S(i) = 1000;
    elseif t(i) < 7
        S(i) = 600;
    else
        S(i) = 800;
    end
end

dV        = 0.3;
V_mppt    = zeros(1,N);
P_mppt    = zeros(1,N);
I_mppt    = zeros(1,N);
mod_durum = zeros(1,N);
V_mppt(1) = 17.2;

for i = 1:N
    Iph = Isc * (S(i)/1000);
    x   = Iph * 0.9;
    for it = 1:500
        ex = exp((V_mppt(i) + x*Rs) / Vt);
        f  = Iph - I0*(ex-1) - (V_mppt(i)+x*Rs)/Rsh - x;
        df = -I0*(Rs/Vt)*ex - Rs/Rsh - 1;
        dx = f/df;
        x  = x - dx;
        if abs(dx) < 1e-12
            break
        end
    end
    if x < 0
        x = 0;
    end
    I_mppt(i) = x;
    P_mppt(i) = V_mppt(i) * I_mppt(i);
    if V_mppt(i) > V_solar_esik
        mod_durum(i) = 1;
    elseif V_mppt(i) < V_sebeke_esik
        mod_durum(i) = 0;
    else
        if i > 1
            mod_durum(i) = mod_durum(i-1);
        end
    end
    if i < N
        if i == 1
            V_mppt(i+1) = V_mppt(i) + dV;
        else
            dP  = P_mppt(i) - P_mppt(i-1);
            dVv = V_mppt(i) - V_mppt(i-1);
            if dP == 0
                V_mppt(i+1) = V_mppt(i);
            elseif dP > 0
                if dVv > 0
                    V_mppt(i+1) = V_mppt(i) + dV;
                else
                    V_mppt(i+1) = V_mppt(i) - dV;
                end
            else
                if dVv > 0
                    V_mppt(i+1) = V_mppt(i) - dV;
                else
                    V_mppt(i+1) = V_mppt(i) + dV;
                end
            end
        end
        if V_mppt(i+1) < 0.5
            V_mppt(i+1) = 0.5;
        end
        if V_mppt(i+1) > Voc
            V_mppt(i+1) = Voc;
        end
    end
end

figure('Position', [100 100 900 800]);

subplot(4,1,1);
plot(t, S, 'k', 'LineWidth', 2);
ylabel('Isinim (W/m2)');
title('Gunes Isinmi');
grid on;
ylim([0 1200]);

subplot(4,1,2);
plot(t, P_mppt, 'b', 'LineWidth', 2);
ylabel('Guc (W)');
title('MPPT - Takip Edilen Guc');
grid on;

subplot(4,1,3);
plot(t, V_mppt, 'r', 'LineWidth', 2);
hold on;
yline(13.0, 'g--', 'LineWidth', 1.5, 'Label', 'Solar Esik 13V');
yline(12.0, 'm--', 'LineWidth', 1.5, 'Label', 'Sebeke Esik 12V');
ylabel('Gerilim (V)');
title('MPPT - Calisma Gerilimi');
grid on;
ylim([0 Voc+2]);

subplot(4,1,4);
stairs(t, mod_durum, 'k', 'LineWidth', 2);
ylabel('Mod');
xlabel('Zaman (s)');
title('Sistem Modu  (1=Solar  0=Sebeke)');
yticks([0 1]);
yticklabels({'Sebeke','Solar'});
grid on;
ylim([-0.2 1.2]);

sgtitle('Adim 2: MPPT - Perturb and Observe', 'FontSize', 13);
saveas(gcf, 'Adim2_MPPT.png');
disp('Adim 2 tamam!');