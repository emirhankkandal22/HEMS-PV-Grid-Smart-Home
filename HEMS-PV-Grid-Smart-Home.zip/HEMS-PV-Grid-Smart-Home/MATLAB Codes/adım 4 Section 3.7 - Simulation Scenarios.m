dt    = 0.01;
t_end = 24;
t     = 0:dt:t_end;
N     = length(t);

Isc = 5.0;
Voc = 21.6;
Rs  = 0.4;
Rsh = 400;
n   = 48;
q   = 1.602e-19;
k   = 1.381e-23;
T   = 298.15;
Vt  = n * k * T / q;
I0  = (Isc - Voc/Rsh) / (exp(Voc/Vt) - 1);
Vmp = 17.2;

V_bat_max = 14.4;
V_bat_min = 11.0;
V_bat_nom = 12.0;
Kapasite  = 0.5;
SoC_max   = 0.95;
SoC_min   = 0.20;
eta       = 0.95;

senaryo_isimleri = {'Senaryo 1: Normal Gun', 'Senaryo 2: Bulutlu Gun', 'Senaryo 3: Gece'};
senaryo_carpan   = [1.0, 0.3, 0.0];
senaryo_soc0     = [0.50, 0.70, 0.40];

figure('Position', [50 50 1100 900]);

for s = 1:3
    carpan = senaryo_carpan(s);

    S = zeros(1,N);
    for i = 1:N
        saat = t(i);
        if saat < 6
            S(i) = 0;
        elseif saat < 12
            S(i) = (saat-6)/6 * 1000 * carpan;
        elseif saat < 14
            S(i) = 1000 * carpan;
        elseif saat < 20
            S(i) = (20-saat)/6 * 1000 * carpan;
        else
            S(i) = 0;
        end
    end

    P_yuk = zeros(1,N);
    for i = 1:N
        saat = t(i);
        if saat < 6
            P_yuk(i) = 50;
        elseif saat < 9
            P_yuk(i) = 150;
        elseif saat < 17
            P_yuk(i) = 100;
        elseif saat < 22
            P_yuk(i) = 200;
        else
            P_yuk(i) = 80;
        end
    end

    SoC      = zeros(1,N);
    SoC(1)   = senaryo_soc0(s);
    P_pv     = zeros(1,N);
    P_bat    = zeros(1,N);
    P_sebeke = zeros(1,N);

    for i = 1:N
        Iph = Isc * (S(i)/1000);
        x   = Iph * 0.9;
        for it = 1:500
            ex = exp((Vmp + x*Rs) / Vt);
            f  = Iph - I0*(ex-1) - (Vmp+x*Rs)/Rsh - x;
            df = -I0*(Rs/Vt)*ex - Rs/Rsh - 1;
            dx = f/df;
            x  = x - dx;
            if abs(dx) < 1e-12
                break
            end
        end
        if x < 0
            x = 0;
        end
        P_pv(i) = Vmp * x;

        P_fazla = P_pv(i) - P_yuk(i);

        if P_pv(i) > P_yuk(i)
            if SoC(i) < SoC_max
                P_bat(i)    = P_fazla * eta;
                P_sebeke(i) = 0;
            else
                P_bat(i)    = 0;
                P_sebeke(i) = -P_fazla;
            end
        elseif SoC(i) > SoC_min
            P_bat(i)    = P_fazla / eta;
            P_sebeke(i) = 0;
        else
            P_bat(i)    = 0;
            P_sebeke(i) = -P_fazla;
        end

        if i < N
            dSoC = -P_bat(i) * dt / (Kapasite * V_bat_nom * 3600);
            SoC(i+1) = SoC(i) + dSoC;
            if SoC(i+1) > SoC_max
                SoC(i+1) = SoC_max;
            end
            if SoC(i+1) < SoC_min
                SoC(i+1) = SoC_min;
            end
        end
    end

    subplot(3,3, (s-1)*3 + 1);
    plot(t, P_pv, 'g', 'LineWidth', 2);
    hold on;
    plot(t, P_yuk, 'r', 'LineWidth', 2);
    ylabel('Guc (W)');
    title([senaryo_isimleri{s} ' - Uretim/Tuketim']);
    legend('PV Uretim','Ev Tuketimi','Location','northwest','FontSize',7);
    grid on;

    subplot(3,3, (s-1)*3 + 2);
    plot(t, SoC*100, 'b', 'LineWidth', 2);
    hold on;
    yline(95, 'r--', 'LineWidth', 1.5, 'Label', 'Max %95');
    yline(20, 'r--', 'LineWidth', 1.5, 'Label', 'Min %20');
    ylabel('SoC (%)');
    title('Batarya Sarj Durumu (SoC)');
    grid on;
    ylim([0 105]);

    subplot(3,3, (s-1)*3 + 3);
    plot(t, P_sebeke, 'k', 'LineWidth', 2);
    hold on;
    yline(0, 'b--', 'LineWidth', 1);
    ylabel('Guc (W)');
    title('Sebeke Etkilesimi (+Cekilen / -Verilen)');
    xlabel('Zaman (Saat)');
    grid on;
end

sgtitle('Adim 4: Rule-Based EMS - 3 Senaryo Karsilastirmasi', 'FontSize', 12);
saveas(gcf, 'Adim4_EMS_Final.png');
disp('Adim 4 tamam!');
