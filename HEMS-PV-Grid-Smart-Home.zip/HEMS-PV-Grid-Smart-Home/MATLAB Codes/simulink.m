% =========================================================
% ADIM 5: TAM SISTEM SIMULASYONU
% Home Energy Management System (HEMS)
% PV + Battery + Grid - Rule-Based EMS
% =========================================================

dt    = 0.01;
t_end = 24;
t     = 0:dt:t_end;
N     = length(t);

% ---- PV Parametreleri ----
Isc = 5.0;
Voc = 21.6;
Rs  = 0.4;
Rsh = 400;
n   = 48;
q   = 1.602e-19;
k   = 1.381e-23;
T   = 298.15;
Vt  = n * k * T / q;
I0  = (Isc - Voc/Rsh) / (exp(Voc/Vt) - 1);
Vmp = 17.2;
dV  = 0.3;

% ---- Batarya Parametreleri ----
V_bat_max = 14.4;
V_bat_min = 11.0;
V_bat_nom = 12.0;
Kapasite  = 0.5;
SoC_max   = 0.95;
SoC_min   = 0.20;
eta       = 0.95;

% ---- Başlangıç ----
SoC      = zeros(1,N);
SoC(1)   = 0.60;
V_bat    = zeros(1,N);
V_bat(1) = V_bat_min + SoC(1)*(V_bat_max - V_bat_min);

% ---- Vektörler ----
S        = zeros(1,N);
P_yuk    = zeros(1,N);
P_pv     = zeros(1,N);
P_bat    = zeros(1,N);
P_sebeke = zeros(1,N);
V_mppt   = zeros(1,N);
mod_durum= zeros(1,N); % 1=Solar+Sarj, 2=Solar+Sebeke, 3=Batarya, 4=Sebeke
V_mppt(1)= Vmp;

% ---- Güneş ışınımı (24 saat) ----
for i = 1:N
    saat = t(i);
    if saat < 6
        S(i) = 0;
    elseif saat < 12
        S(i) = (saat-6)/6 * 1000;
    elseif saat < 14
        S(i) = 1000;
    elseif saat < 20
        S(i) = (20-saat)/6 * 1000;
    else
        S(i) = 0;
    end
end

% ---- Ev yük profili ----
for i = 1:N
    saat = t(i);
    if saat < 6
        P_yuk(i) = 50;
    elseif saat < 9
        P_yuk(i) = 150;
    elseif saat < 17
        P_yuk(i) = 100;
    elseif saat < 22
        P_yuk(i) = 200;
    else
        P_yuk(i) = 80;
    end
end

% ---- Ana Simülasyon Döngüsü ----
for i = 1:N

    % 1) PV güç hesabı (Single Diode Model)
    Iph = Isc * (S(i)/1000);
    x   = Iph * 0.9;
    for it = 1:500
        ex = exp((V_mppt(i) + x*Rs) / Vt);
        f  = Iph - I0*(ex-1) - (V_mppt(i)+x*Rs)/Rsh - x;
        df = -I0*(Rs/Vt)*ex - Rs/Rsh - 1;
        dx_iter = f/df;
        x = x - dx_iter;
        if abs(dx_iter) < 1e-12
            break
        end
    end
    if x < 0
        x = 0;
    end
    P_pv(i) = V_mppt(i) * x;

    % 2) MPPT P&O
    if i < N
        if i == 1
            V_mppt(i+1) = V_mppt(i) + dV;
        else
            dP  = P_pv(i) - P_pv(i-1);
            dVv = V_mppt(i) - V_mppt(i-1);
            if dP == 0
                V_mppt(i+1) = V_mppt(i);
            elseif dP > 0
                if dVv > 0
                    V_mppt(i+1) = V_mppt(i) + dV;
                else
                    V_mppt(i+1) = V_mppt(i) - dV;
                end
            else
                if dVv > 0
                    V_mppt(i+1) = V_mppt(i) - dV;
                else
                    V_mppt(i+1) = V_mppt(i) + dV;
                end
            end
        end
        if V_mppt(i+1) < 0.5
            V_mppt(i+1) = 0.5;
        end
        if V_mppt(i+1) > Voc
            V_mppt(i+1) = Voc;
        end
    end

    % 3) Rule-Based EMS
    P_fazla = P_pv(i) - P_yuk(i);

    if P_pv(i) > P_yuk(i)
        if SoC(i) < SoC_max
            % Kural 1: PV fazla, batarya dolu degil → sarj et
            P_bat(i)    = P_fazla * eta;
            P_sebeke(i) = 0;
            mod_durum(i)= 1;
        else
            % Kural 2: PV fazla, batarya dolu → sebekeye ver
            P_bat(i)    = 0;
            P_sebeke(i) = -P_fazla;
            mod_durum(i)= 2;
        end
    elseif SoC(i) > SoC_min
        % Kural 3: PV yetersiz, batarya var → bataryadan al
        P_bat(i)    = P_fazla / eta;
        P_sebeke(i) = 0;
        mod_durum(i)= 3;
    else
        % Kural 4: PV yetersiz, batarya bos → sebekeden cek
        P_bat(i)    = 0;
        P_sebeke(i) = -P_fazla;
        mod_durum(i)= 4;
    end

    % 4) SoC güncelle
    if i < N
        dSoC = -P_bat(i) * dt / (Kapasite * V_bat_nom * 3600);
        SoC(i+1) = SoC(i) + dSoC;
        if SoC(i+1) > SoC_max
            SoC(i+1) = SoC_max;
        end
        if SoC(i+1) < SoC_min
            SoC(i+1) = SoC_min;
        end
        V_bat(i+1) = V_bat_min + SoC(i+1)*(V_bat_max - V_bat_min);
    end
end

% =========================================================
% GRAFİKLER
% =========================================================
figure('Position', [50 50 1100 950]);

subplot(6,1,1);
plot(t, S, 'b', 'LineWidth', 2);
ylabel('W/m2');
title('Gunes Isinmi (24 Saat)');
grid on;
ylim([0 1200]);

subplot(6,1,2);
plot(t, P_pv, 'g', 'LineWidth', 2);
hold on;
plot(t, P_yuk, 'r', 'LineWidth', 2);
ylabel('Guc (W)');
title('PV Uretim vs Ev Tuketimi');
legend('PV Uretim', 'Ev Tuketimi', 'Location', 'northwest', 'FontSize', 8);
grid on;

subplot(6,1,3);
plot(t, SoC*100, 'b', 'LineWidth', 2);
hold on;
yline(95, 'r--', 'LineWidth', 1.5, 'Label', 'Max %95');
yline(20, 'r--', 'LineWidth', 1.5, 'Label', 'Min %20');
ylabel('SoC (%)');
title('Batarya Sarj Durumu (SoC)');
grid on;
ylim([0 105]);

subplot(6,1,4);
plot(t, V_bat, 'm', 'LineWidth', 2);
ylabel('Voltaj (V)');
title('Aku Voltaji');
grid on;
ylim([10 16]);

subplot(6,1,5);
plot(t, P_sebeke, 'k', 'LineWidth', 2);
hold on;
yline(0, 'b--', 'LineWidth', 1);
ylabel('Guc (W)');
title('Sebeke Etkilesimi (+Cekilen / -Verilen)');
grid on;

subplot(6,1,6);
stairs(t, mod_durum, 'k', 'LineWidth', 2);
ylabel('Mod');
xlabel('Zaman (Saat)');
title('EMS Mod Durumu');
yticks([1 2 3 4]);
yticklabels({'Solar+Sarj','Solar+Sebeke','Batarya','Sebeke'});
grid on;
ylim([0 5]);

sgtitle('Adim 5: Tam Sistem Simulasyonu - HEMS', 'FontSize', 13, 'FontWeight', 'bold');
saveas(gcf, 'Adim5_Tam_Sistem.png');
disp('Adim 5 tamam! Tum sistem simulasyonu tamamlandi.');
